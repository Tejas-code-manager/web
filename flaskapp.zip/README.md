Clone this project

pip3 install -r requirements.txt

Change the password in db.yaml to that of your MySQL's password

Run the application by executing the command python3 app.py

The application runs on localhost:5000
